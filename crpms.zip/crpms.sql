-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2025 at 11:17 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crpms`
--

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

CREATE TABLE `car` (
  `id` int(200) NOT NULL,
  `pname` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `model` varchar(200) NOT NULL,
  `myear` date NOT NULL,
  `dphone` int(244) NOT NULL,
  `mname` varchar(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `car`
--

INSERT INTO `car` (`id`, `pname`, `type`, `model`, `myear`, `dphone`, `mname`) VALUES
(3, '345', 'mk', 'bm', '2025-05-08', 98898, 'hirw'),
(4, '2003th', 'ranger lover', 'youdai', '2025-05-08', 79355672, 'slima'),
(5, '233', 'ggf', 'ydai', '2025-05-02', 789878787, 'thomas mdrew'),
(6, '89399kj', 'fuso', 'fso', '2025-05-07', 2147483647, 'joe'),
(7, 'wash', 'yai', 'mn', '2025-05-08', 7888778, 'manz');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` int(200) NOT NULL,
  `S_code` varchar(200) NOT NULL,
  `S_name` varchar(200) NOT NULL,
  `S_price` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `S_code`, `S_name`, `S_price`) VALUES
(1, '300039', 'Washincar', '20000$'),
(2, '2343', 'repaire battery', '30000frw'),
(3, '300989', 'washing', '9000000000'),
(4, '300989', 'washing', '9000000000'),
(5, '300989', 'washing', '9000000000'),
(6, '300989', 'washing', '9000000000'),
(7, '2443', 'repaire', '2000'),
(8, '40089', 'paint', '70000');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `names` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `names`, `email`, `username`, `password`) VALUES
(23, '20223', 'v@gmail.com', '20/30/2007', 'v'),
(24, '1023', 'sds', '22/09/2005', 'sd'),
(32, 'hy', '', 'hy', 'hy'),
(33, 'nkaka', '', 'nkaka', '567890');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `car`
--
ALTER TABLE `car`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
