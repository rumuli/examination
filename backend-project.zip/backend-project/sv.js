const mysql = require('mysql')
const connect = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"crpms"
})

connect.connect((err)=>{
    if(err)throw err
    console.log("connected")
})

const express = require('express')
const app = express()

app.listen(5000,()=>{
    console.log("server is connected")
})

app.use(express.json())
const bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({extended:true}))

const cors = require('cors')
app.use(cors())

//sql

app.post('/inser', (req,res)=>{
    const value = [req.body.getS_code, req.body.getS_name, req.body.getS_price]
    const sql = "INSERT INTO `service`(`S_code`, `S_name`, `S_price`) VALUES (?,?,?)"
    connect.query(sql, value, (err)=>{
        if(err)console.log(err)
            console.log("inserted")
    })
})
//sel
app.get('/dataservice', (req,res)=>{
    const sel = "SELECT * FROM `service`"

    connect.query(sel, (err, data)=>{
        if(err)console.log(err)
            res.send(data)
    })
})

//inser car

app.post('/insertcar', (req,res)=>{
    const values = [req.body.getpname, req.body.gettype, req.body.getmodel, req.body.getmyear, req.body.getdphone, req.body.getmname]
    const sqlc = "INSERT INTO `car`(`pname`, `type`, `model`, `myear`, `dphone`, `mname`) VALUES (?,?,?,?,?,?)"
    connect.query(sqlc, values, (err)=>{
        if(err)console.log(err)
            console.log("inserted")
    })
})
//select car
app.get('/selectcar', (req,res)=>{
    const sele = "SELECT * FROM `car`"

    connect.query(sele, (err, data)=>{
        if(err)console.log(err)
            res.send(data)
    })
})