import { useEffect, useState } from "react"
import axios from "axios"
import Display from "./Display"
const Carlist =()=>{
 const [car, setcar] = useState([])
 useEffect(()=>{
    fetchcar()
 }, [])

 const fetchcar = ()=>{
    axios.get("http://localhost:5000/selectcar")
    .then((Response)=>{setcar(Response.data)})
 }
    return(
        <>
        <Display/>
          <h1 className="ml-120 mt-3 font-bold text-blue-900"> Car list </h1>
        <table className="border-1 border-blue-900 mt-3 ml-50">
            <thead>
                <th className=" bg-blue-900 text-white p-2">Plate No</th>
                <th className=" bg-blue-900 text-white p-2">type</th>
                <th className=" bg-blue-900 text-white p-2">Model</th>
                <th className=" bg-blue-900 text-white p-2">Manufacture Year</th>
                <th className=" bg-blue-900 text-white p-2">Driver phone</th>
                <th className=" bg-blue-900 text-white p-2">Mechanic name</th>
            </thead>
            <tbody>
                {car.map((car, index)=>
                <tr key={car.id}>
                    <td>{car.pname}</td>
                    <td>{car.type}</td>
                    <td>{car.model}</td>
                    <td>{car.myear}</td>
                    <td>{car.dphone}</td>
                    <td>{car.mname}</td>
                </tr>
                )}
            </tbody>
        </table>

        </>
    )
}
export default Carlist