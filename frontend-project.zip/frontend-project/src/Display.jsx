import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Nav from './Nav';

function Display() {
  // const [data, setData] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Track user session

  


  // Handle user logout
  const handleLogout = () => {
    axios.post('http://localhost:8000/logout')
      .then(() => {
        setIsLoggedIn(false); // Update state to reflect logged out status
      })
      .catch((err) => {
        console.error("Logout error:", err);
      });
  };



  return (
    <div className="max-w-6xl mx-auto mt-10 p-4">
      {/* Session Button */}
      <div className="flex justify-between mb-4">
      <Nav/>

        {isLoggedIn ? (
          <button 
            onClick={handleLogout} 
            className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">Logout</button>) : (<Link to="/">
            <button className="bg-blue-900 text-white px-3 py-1 rounded hover:bg-blue-800">Logout</button></Link>)}
      </div>

  
    </div>
  );
}

export default Display;
