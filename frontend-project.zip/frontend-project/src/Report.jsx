import { useEffect, useState } from "react"
import axios from "axios"
import Display from "./Display"
const Report = () => {
  const [car, setcar] = useState([])
  useEffect(() => {
    fetchcar()
  }, [])

  const fetchcar = () => {
    axios.get("http://localhost:5000/selectcar")
      .then((Response) => { setcar(Response.data) })
  }
  return (
    <>
      <Display />
      <h1 className="ml-120 mt-3 font-bold text-blue-900"> Report </h1>
      <div className="overflow-x-auto ml-2 mt-4">
        <table className="min-w-full bg-white border border-gray-300">
          <thead>
            <tr>
              <th className="px-4 py-2 border">Date (UTC)</th>
              <th className="px-4 py-2 border">Customer Name</th>
              <th className="px-4 py-2 border">Service Code</th>
              <th className="px-4 py-2 border">Download Link</th>
            </tr>
          </thead>
          <tbody>
            {car.map((car, index) => (
              <tr key={car.id || index}>
                <td className="px-4 py-2 border">{car.date || "N/A"}</td>
                <td className="px-4 py-2 border">{car.mname || "N/A"}</td>
                <td className="px-4 py-2 border">{car.model || "N/A"}</td>
                <td className="px-4 py-2 border">
                  <a
                    href={car.downloadUrl || "#"}
                    className="bg-blue-300 hover:underline rounded text-white p-1"
                    download
                  >
                    Download file
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}
export default Report