import Display from "./Display"
const Payment=()=>{
    return(
<> 
    <Display/>
<div className="py ml-80">
            <label htmlFor="">Payment number</label><br />
            <input type="number"  placeholder="Payment number" className="border-1 w-100 h-8" /><br />
            <label htmlFor="">Amount</label><br />
            <input type="text"   className="border-1 w-100 h-8" placeholder="Amount" /><br />
            <label htmlFor="">Payment date</label><br />
            <input type="date" oplaceholder="Enter Driver Phone" className="border-1 w-100 h-8" /><br /><br />
            <button className="bg-blue-900 text-white hover:underline rounded p-2 w-100">Payment</button>
            </div>
</>
    )
}
export default Payment 