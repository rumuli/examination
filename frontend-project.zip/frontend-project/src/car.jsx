import { useState } from "react"
import Nav from "./Nav"
import axios from "axios"
import Display from "./Display"
import { Link } from "react-router-dom"
const Car =()=>{
    const [getpname, setpname] = useState('')
    const [gettype, settype] = useState('')
    const [getmodel, setmodel] = useState('')
    const [getmyear, setmyear] = useState('')
    const [getdphone, setdphone] = useState('')
    const [getmname, setmname] = useState('')

    const insertcar = ()=>{
        axios.post("http://localhost:5000/insertcar", {getpname, gettype, getmodel, getmyear, getdphone, getmname})
        .catch((err)=>{console.log(err)})
        window.alert("Car is inserted now")
        window.location.href = "/carlist"
    }
    return(
        <>
        <Display/>
        <div className="car ml-100">
            <h1>Enter car </h1>
            <label htmlFor="">Plate No</label><br />
            <input type="text" onChange={(e)=>{setpname(e.target.value)}} placeholder="Enetr Plate No" className="border-1 w-100 h-8"  /><br />
            <label htmlFor="">Type</label><br />
            <input type="text" onChange={(e)=>{settype(e.target.value)}} placeholder="Enter Type" className="border-1 w-100 h-8" /><br />
            <label htmlFor="">Model</label><br />
            <input type="text" onChange={(e)=>{setmodel(e.target.value)}} placeholder="Enter Model" className="border-1 w-100 h-8" /><br />
            <label htmlFor="">Manufacture_Year</label><br />
            <input type="date" onChange={(e)=>{setmyear(e.target.value)}}  className="border-1 w-100 h-8" /><br />
            <label htmlFor="">Driver Phone</label><br />
            <input type="number" onChange={(e)=>{setdphone(e.target.value)}}placeholder="Enter Driver Phone" className="border-1 w-100 h-8" /><br />
            <label htmlFor="">Mechanic Name</label><br />
            <input type="text" onChange={(e)=>{setmname(e.target.value)}} placeholder="Enter Mechanic name" className=" border-1 w-100 h-8"   /><br /><br />

            <button onClick={insertcar} className="bg-blue-800 rounded p-2 w-100 hover:underline text-white">Enter Car</button><br /><br />
           <Link to="../carlist"><button className="bg-blue-100 rounded p-2 w-100 hover:underline text-blue-800">Show Cars list</button></Link>
        </div>
        </>
    )
}
export default Car