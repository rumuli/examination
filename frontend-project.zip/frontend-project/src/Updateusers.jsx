import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';

function UpdateUsers() {
  const { id } = useParams();
  const [names, setNames] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    axios.get(`http://localhost:8000/users/${id}`)
      .then((res) => {
        setNames(res.data.names);
        setEmail(res.data.email);
        setUsername(res.data.username);
        setPassword(res.data.password);
      })
      .catch((err) => {
        console.error("Error fetching user:", err);
      });
  }, [id]);

  const handleUpdate = (e) => {
    e.preventDefault();
    axios.put(`http://localhost:8000/users/${id}`, {
      names,
      email,
      username,
      password
    })
      .then(() => {
        alert("User updated successfully!");
        window.location.href = "/servicerecord"
      })
      .catch((err) => {
        console.error("Update error:", err);
      });
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6 text-center">Update User</h2>
      <form onSubmit={handleUpdate} className="space-y-4">

        <div>
          <label htmlFor="names" className="block text-sm font-medium text-gray-700">RecordNumber</label>
          <input
            type="text"
            id="names"
            value={names}
            onChange={(e) => setNames(e.target.value)}
            className="mt-1 block w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
        
        </div>

        <div>
          <label htmlFor="username" className="block text-sm font-medium text-gray-700">Service Date</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="mt-1 block w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
         
        </div>

        <div className="flex items-center justify-between">
          <button
            type="submit"
            className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
          >
            Update
          </button>
          <Link
            to="/servicerecord"
            className="text-sm text-blue-600 hover:underline"
          >
            Back To List
          </Link>
        </div>

      </form>
    </div>
  );
}

export default UpdateUsers;
