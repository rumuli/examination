import axios from 'axios';
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Display from './Display';
const Record=()=>{
  const [data, setData] = useState([]);

 // Check user session on component mount
  useEffect(() => {
    // Check if the user is logged in (assuming a /session endpoint that returns the session status)
    axios.get('http://localhost:8000/session')
      .then((response) => {
        setIsLoggedIn(response.data.loggedIn); // Assuming the response has a loggedIn field
      })
      .catch((error) => {
        console.error("Error fetching session status:", error);
      });

    // Fetch the data for the users
    axios.get('http://localhost:8000/databa')
      .then((response) => {
        setData(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

    const handleDelete = (id) => {
    axios.delete(`http://localhost:8000/delete/${id}`)
      .then(() => {
        // Remove
        setData(data.filter(user => user.id !== id));
      })
      .catch((err) => {
        console.error("Delete error:", err);
      });
  };
    return(
        <>
        <Display/>
        <table className=" border border-blue-900 text-sm ml-90">
        <thead className="bg-gray-100">
          <tr>
            <th className=" bg-blue-800 p-2 text-white">RecordName</th>
            <th className=" bg-blue-800 p-2 text-white">RecordDate</th>
            <th className=" bg-blue-800 p-2 text-white">Controls</th>
          </tr>
        </thead>
        <tbody>
          {data.map((val,i) => (
            <tr key={i} className="hover:bg-gray-50">
              <td className=" ">{val.names}</td>
              <td className=" ">{val.username}</td>
              <td className="  flex gap-2 justify-center">
                <Link to={`/updateusers/${val.id}`}>
                  <button className="bg-blue-400 text-white mt-2   p-2 px-7 rounded hover:bg-blue-500">Update</button>
                </Link>
                <button
                  onClick={() => handleDelete(val.id)}
                  className="bg-red-500 text-white  mt-2 rounded p-2 px-7 hover:bg-red-600"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
        </>
    )
}
export default Record