import React from 'react'
import Display from './Display'
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import Login from './Login'
import Register from './Register'
import Updateusers from './Updateusers'
import Service from './services'
import Nav from './Nav'
import Record from './servicerecord'
import SendService from './Sendservice'
import Car from './car'
import Report from './Report'
import Carlist from './carlist'
import Payment from './payment'
function App() {
  return (
    <>
    <h1 className='text-center bg-blue-900 text-white p-3'>CPRM System</h1>
    <Router>

    <Routes>
      <Route path='/Nav' element={<Nav/>}></Route>
      <Route path='/Report' element={<Report/>}></Route>
      <Route path='/payment' element={<Payment/>}></Route>
      <Route path='/car' element={<Car/>}></Route>
      <Route path='/carlist' element={<Carlist/>}></Route>
      <Route path='/servicerecord' element={<Record/>}></Route>
      <Route path='/Sendservices' element={<SendService/>}></Route>
      <Route path='/services' element={<Service/>}></Route>
      <Route path='/' element={<Login/>}></Route>
      <Route path='/display' element={<Display/>}></Route>
      <Route path='/register' element={<Register/>}></Route>
      <Route path='/updateusers/:id' element={<Updateusers/>}></Route>
    </Routes>
</Router>
</>
  )
}

export default App