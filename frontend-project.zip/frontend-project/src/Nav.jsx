import { Link } from "react-router-dom"
const Nav =()=>{
    
    return(
        <> 
        <div className="nav flex ">
           <Link to="../car"> <button className="bg-blue-900 text-white p-2 ml-2 mt-2 w-30 hover:underline hover:bg-blue-800 rounded">Car</button></Link>
          <Link to="../services"><button className="bg-blue-900 text-white p-2 ml-2 mt-2 w-30 hover:underline hover:bg-blue-800 rounded">Services</button></Link>
           <Link to="../servicerecord"><button className="bg-blue-900 text-white p-2 ml-2 mt-2 w-30 hover:underline hover:bg-blue-800 rounded">ServiceRecord</button></Link>
          <Link to="../payment"><button className="bg-blue-900 text-white p-2 ml-2 mt-2 w-30 hover:underline hover:bg-blue-800 rounded">Payment</button></Link>
            <Link to="../Report"><button className="bg-blue-900 text-white p-2 ml-2 mt-2 w-30 hover:underline hover:bg-blue-800 rounded">Report</button></Link>

        </div>
        </>
    )
}
export default Nav