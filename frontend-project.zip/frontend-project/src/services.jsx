import { useEffect, useState } from "react"
import Display from "./Display"
import { Link } from "react-router-dom"
import axios from "axios"
const Service =()=>{
    const [service, setservice] = useState([])

    useEffect(()=>{
        fetchservice()
    },[])

    const fetchservice = ()=>{
        axios.get("http://localhost:5000/dataservice")
        .then((Response)=>{setservice(Response.data)})
    }
    return(
        <>
        <Display/>
        <Link to="../Sendservices"><button className="bg-blue-900 hover:underline ml-100 p-2 w-40 rounded text-white"> Send services</button></Link>
        <table className="border-1 ml-100 border-blue-900 mt-2">
            <thead >
                <th className="bg-blue-900 text-white p-3">ServiceCode</th>
                <th className="bg-blue-900 text-white p-3">ServiceName</th>
                <th className="bg-blue-900 text-white p-3">ServiceProduct</th>
            </thead>
            <tbody>
                {service.map((service, index)=>
                <tr key={service.id}>
                    <td>{service.S_code}</td>
                    <td>{service.S_name}</td>
                    <td>{service.S_price}</td>
                </tr>
                )}
            </tbody>
        </table>
        </>
    )
}
export default Service