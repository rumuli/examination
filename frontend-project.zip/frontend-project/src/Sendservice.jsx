import { useState } from "react"
import Display from "./Display"
import { Link, Navigate } from "react-router-dom"
import axios from "axios"
const SendService =()=>{
    const [getS_code, setS_code] = useState('')
    const [getS_name, setS_name] = useState('')
    const [getS_price, setS_price] = useState('')

    const handl_insert =()=>{
        axios.post("http://localhost:5000/inser", {getS_code, getS_name, getS_price})
        .catch((err)=>{console.log(err)})
        window.alert("send services are sended")
        window.location.href="/services"
    }

    return(
        <>
        <Display/>
        <div className="sen ml-100">
        <h1 className=""> send Services to the system</h1>
        <label htmlFor="">ServiceCode</label><br />
        <input type="text" onChange={(e)=>{setS_code(e.target.value)}} className="w-100 h-9 border-1 border-blue-900" placeholder="Enter service code" /><br />
        <label htmlFor="">ServiceName</label><br />
        <input type="text" onChange={(e)=>{setS_name(e.target.value)}} className="w-100 h-9 border-1 border-blue-900" placeholder="Enter service name" /><br />
        <label htmlFor="">ServicePrice</label><br />
        <input type="text"  onChange={(e)=>{setS_price(e.target.value)}} className="w-100 h-9 border-1 border-blue-900" placeholder="Enter service price" /><br /><br />
        <button onClick={handl_insert} className="bg-blue-900 p-2  text-white w-100 rounded">Send</button>
        </div>
        </>
    )
}
export default SendService